# 導入數據模型ArticlePost
from django.views import View
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView

from .models import ArticlePost
# 導入模型markdown
import markdown
# 引入redirect render重定向模塊
from django.shortcuts import render, redirect
# 引入HttpResponse
from django.http import HttpResponse
# 引入剛才定義的ArticlePostForm表單類
from .forms import ArticlePostForm
# 引入User模型
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from comment.models import Comment
from .models import ArticleColumn
from comment.forms import CommentForm
from django.shortcuts import get_object_or_404


def article_list(request):
    search = request.GET.get('search')
    order = request.GET.get('order')
    column = request.GET.get('column')
    tag = request.GET.get('tag')
    # 用戶搜索邏輯
    # 初始化查询集
    article_list = ArticlePost.objects.all()

    # 搜索查询集
    if search:
        article_list = article_list.filter(
            Q(title__icontains=search) |
            Q(body__icontains=search)
        )
    else:
        search = ''

    # 栏目查询集
    if column is not None and column.isdigit():
        article_list = article_list.filter(column=column)

    # 标签查询集
    if tag and tag != 'None':
        article_list = article_list.filter(tags__name__in=[tag])

    # 查询集排序
    if order == 'total_views':
        article_list = article_list.order_by('-total_views')

    paginator = Paginator(article_list, 3)
    page = request.GET.get('page')
    articles = paginator.get_page(page)

    # 需要传递给模板（templates）的对象
    context = {
        'articles': articles,
        'order': order,
        'search': search,
        'column': column,
        'tag': tag,
    }

    return render(request, 'article/list.html', context)


# 文章詳情
def article_detail(request, id):
    # 取出相應的文章
    # article = ArticlePost.objects.get(id=id)
    article = get_object_or_404(ArticlePost, id=id)
    comments = Comment.objects.filter(article=id)
    # 瀏覽量 +1
    article.total_views += 1
    article.save(update_fields=['total_views'])
    # 將markdown語法渲染成html樣式
    article.body = markdown.markdown(article.body,
                                     extensions=[
                                         # 包含 縮寫、表格等常用擴展
                                         'markdown.extensions.extra',
                                         # 語法高亮擴展
                                         'markdown.extensions.codehilite',
                                     ])
    comment_form = CommentForm()
    # 需要傳遞給模板的對象
    context = {'article': article, 'comments': comments, 'comment_form': comment_form, }
    # 載入模板，並返回context對象
    return render(request, 'article/detail.html', context)


# 寫文章的views
# 檢查登錄
@login_required(login_url='/userprofile/login/')
def article_create(request):
    # 判斷用戶是否提交數據
    if request.method == "POST":
        # 將提交的數據賦值到表單實例中
        article_post_form = ArticlePostForm(request.POST, request.FILES)
        # 判斷提交的數據是否滿足模型的要求
        if article_post_form.is_valid():
            # 保存數據，但暫時不提交到數據庫中
            new_article = article_post_form.save(commit=False)
            # 指定目前登錄的用戶為作者
            new_article.author = User.objects.get(id=request.user.id)
            # column
            if request.POST['column'] != 'none':
                new_article.column = ArticleColumn.objects.get(id=request.POST['column'])
            # 將新文章保存到數據庫中
            new_article.save()
            # tag more to more
            article_post_form.save_m2m()
            # 完成後返回到文章列表
            return redirect("article:article_list")
        # 如果數據有誤，返回錯誤信息
        else:
            return HttpResponse("內容有誤，請重新填寫。")
    # 如果用戶請求獲取數據
    else:
        # 創建表單類實例
        article_post_form = ArticlePostForm()
        # 賦值上下文
        columns = ArticleColumn.objects.all()
        context = {'article_post_form': article_post_form, 'columns': columns}
        # 返回模板
        return render(request, 'article/create.html', context)


# 刪文章
def article_delete(request, id):
    # 根据 id 获取需要删除的文章
    article = ArticlePost.objects.get(id=id)
    # 调用.delete()方法删除文章
    article.delete()
    # 完成删除后返回文章列表
    return redirect("article:article_list")


# 安全刪除文章
def article_safe_delete(request, id):
    if request.method == 'POST':
        article = ArticlePost.objects.get(id=id)
        article.delete()
        return redirect("article:article_list")
    else:
        return HttpResponse("僅允許post請求")


# 更新文章
# 提醒用戶登錄
@login_required(login_url='/userprofile/login/')
def article_update(request, id):
    """
    更新文章的視圖函數
    通過POST方法提交表單，更新titile、body字段
    GET方法進入初始表單頁面
    id： 文章的 id
    """

    # 獲取需要修改的具體文章對象
    article = ArticlePost.objects.get(id=id)
    # 過濾非作者的用戶
    if request.user != article.author:
        return HttpResponse("Sorry, you do not have permission to modify this article.")
    # 判断用户是否为 POST 提交表单数据
    if request.method == "POST":
        # 將提交的數據賦值到表單實例中
        article_post_form = ArticlePostForm(data=request.POST)
        # 判斷提交的數據是否滿足模型的要求
        if article_post_form.is_valid():
            # 保存新寫入的 title、body 數據並保存
            article.title = request.POST['title']
            article.body = request.POST['body']
            if request.FILES.get('avatar'):
                article.avatar = request.FILES.get('avatar')

            article.tags.set(*request.POST.get('tags').split(','), clear=True)
            article.save()
            # if request.POST['column'] != 'none':
            #    article.column = ArticleColumn.objects.get(id=request.POST['column'])
            # else:
            #    article.column = None
            # article.save()
            # 完成後返回到修改後的文章中。需傳入文章的 id 值
            return redirect("article:article_detail", id=id)
        # 如果數據錯誤，返回錯誤信息
        else:
            return HttpResponse("The content of the form is incorrect, please re-fill.")

    # 如果用戶 GET 請求獲取數據
    else:
        # 創建表單類實例
        article_post_form = ArticlePostForm()
        # 賦值上下文，將 article 文章對像也傳遞進去，以便提取舊的內容
        columns = ArticleColumn.objects.all()
        context = {
            'article': article,
            'article_post_form': article_post_form,
            'columns': columns,
            'tags': ','.join([x for x in article.tags.names()]),
        }
        # 將響應返回到模板中
        return render(request, 'article/update.html', context)


# 点赞数 +1
