修改了modeles檔，都需要用和這兩條指令遷移數據:

> python manage.py makemigrations

> python manage.py migrate

create admin:

> python manage.py createsuperuser

run server:
> python manage.py runserver

run on aws  cloud9 :
> python manage.py runserver 8080 --insecure


Windows 10 : venv

> pip install virtualenv

> cd venv

> .\Scripts\activate.bat

> .\Scripts\deactivate.bat


linux : venv

> python3 -m venv venv

> source ./venv/bin/activate


update the requirements.txt:

> pip freeze > requirements.txt

install pip :
> pip install -r requirements.txt


* python manage.py startapp order *

# django db to AWS RDS <setting.py>

        'default': {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': os.environ['RDS_DB_NAME'],
            'USER': os.environ['RDS_USERNAME'],
            'PASSWORD': os.environ['RDS_PASSWORD'],
            'HOST': os.environ['RDS_HOSTNAME'],
            'PORT': os.environ['RDS_PORT'],
        }












 
