from django.apps import AppConfig


class UserprofileConfig(AppConfig):
    name = 'userprofile'
