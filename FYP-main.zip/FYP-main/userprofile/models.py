from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver


# 用戶擴展信息
class Profile(models.Model):
    # 與 User models構成一對一的關係
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    # 電話號碼字段
    phone = models.CharField(max_length=20, blank=True)
    # 頭像
    avatar = models.ImageField(upload_to='avatar/%Y%m%d/', blank=True)
    # 個人簡介
    bio = models.TextField(max_length=500, blank=True)

    def __str__(self):
        return 'user {}'.format(self.user.username)

# 信號接收函數，每當新建 User 實例時自動調用
# @receiver(post_save, sender=User)
# def create_user_profile(sender, instance, created, **kwargs):
#    if created:
#       Profile.objects.create(user=instance)


# 信號接收函數，每當新建 User 實例時自動調用
# @receiver(post_save, sender=User)
# def save_user_profile(sender, instance, **kwargs):
#   instance.profile.save()
